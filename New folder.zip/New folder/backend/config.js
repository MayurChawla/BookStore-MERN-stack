export const PORT = 5555;

export const MongoDBURL = "mongodb+srv://root:root@books-store-mern.qhcr0pk.mongodb.net/books-collection?retryWrites=true&w=majority&appName=Books-Store-MERN"